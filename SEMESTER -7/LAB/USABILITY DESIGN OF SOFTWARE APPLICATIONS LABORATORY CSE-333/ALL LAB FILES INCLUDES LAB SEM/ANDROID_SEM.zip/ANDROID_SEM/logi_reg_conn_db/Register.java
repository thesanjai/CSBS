package com.example.enter;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        final Button register = findViewById(R.id.rbutton);
        final EditText name = findViewById(R.id.editTextText);
        final EditText email = findViewById(R.id.rmail);
        final EditText password = findViewById(R.id.rpass);
        final EditText cpassword = findViewById(R.id.rcpass);
        SQLiteDatabase sq = openOrCreateDatabase("database", Context.MODE_PRIVATE,null);
        sq.execSQL("create table if not exists data(name varchar,password varchar,email varchar)");
        register.setOnClickListener(v->{
            String dname = name.getText().toString();
            String demail = email.getText().toString();
            String dpassword = password.getText().toString();
            String ecpassword = cpassword.getText().toString();
            if(!ecpassword.equals(dpassword)){
                notify("Error", "Password Mismatch");
            }
            else
            {
                sq.execSQL("insert into data values('"+dname+"','"+dpassword+"','"+demail+"')");
                notify("Success","Registration Successful");
            }
        });
    }
    protected void notify(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setCancelable(true);
        builder.show();
    }
}