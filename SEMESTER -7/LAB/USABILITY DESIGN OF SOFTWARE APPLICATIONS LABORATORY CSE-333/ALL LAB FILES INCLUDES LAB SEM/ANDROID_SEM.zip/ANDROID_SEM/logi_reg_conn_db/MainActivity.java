package com.example.enter;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    int enterCount = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        final Button register = findViewById(R.id.reg);
        final EditText email = findViewById(R.id.email);
        final EditText password = findViewById(R.id.password);
        final Button login = findViewById(R.id.lbutton);
        SQLiteDatabase sq = openOrCreateDatabase("database", Context.MODE_PRIVATE,null);
        sq.execSQL("create table if not exists data(name varchar,password varchar,email varchar)");
        login.setOnClickListener(v->{
            String demail = email.getText().toString();
            String dpassword = password.getText().toString();
            Cursor cr = sq.rawQuery("select * from data where email='"+demail+"' and password='"+dpassword+"'",null);
            if(cr.getCount()==0){
                notify("Error","Invalid Email or Password");
            }
            else {
                notify("Success","Login Successful");
            }
        });
        register.setOnClickListener(v-> {
            Intent intent = new Intent(MainActivity.this,Register.class);
            startActivity(intent);
        });
    }
    protected void notify(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setCancelable(true);
        builder.show();
    }
}