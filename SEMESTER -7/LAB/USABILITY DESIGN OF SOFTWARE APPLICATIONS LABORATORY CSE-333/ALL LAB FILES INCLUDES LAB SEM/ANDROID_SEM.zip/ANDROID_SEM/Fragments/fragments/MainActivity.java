package com.example.fragments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.Button;

import com.example.fragments.FragmentOne;
import com.example.fragments.FragmentTwo;
import com.example.fragments.R;

public class MainActivity extends AppCompatActivity {

    Button btnFragmentOne, btnFragmentTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnFragmentOne = findViewById(R.id.btnFragmentOne);
        btnFragmentTwo = findViewById(R.id.btnFragmentTwo);

        // Default fragment
        replaceFragment(new FragmentOne());

        btnFragmentOne.setOnClickListener(v -> replaceFragment(new FragmentOne()));
        btnFragmentTwo.setOnClickListener(v -> replaceFragment(new FragmentTwo()));
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.fragmentContainer, fragment);
        ft.commit();
    }
}
