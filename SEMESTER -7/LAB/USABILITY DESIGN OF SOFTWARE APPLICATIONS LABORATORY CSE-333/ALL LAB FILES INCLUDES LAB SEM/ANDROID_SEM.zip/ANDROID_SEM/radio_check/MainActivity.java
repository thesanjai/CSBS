package com.example.radio_check;

import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        final RadioGroup radioGroup = findViewById(R.id.se);
        final TextView fun = findViewById(R.id.select);
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton selectedGender = findViewById(checkedId);
            if (selectedGender != null) {
                fun.setText("Selected: " + selectedGender.getText().toString());
            }
        });
    }
}