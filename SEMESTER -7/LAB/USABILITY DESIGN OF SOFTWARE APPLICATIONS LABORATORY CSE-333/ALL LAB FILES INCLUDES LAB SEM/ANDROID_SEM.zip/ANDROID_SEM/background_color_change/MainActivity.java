package com.example.back_colour;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import java.util.Random;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    int image_index = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        final ImageView image = findViewById(R.id.image1);
        final int images[] = {R.drawable.image1,R.drawable.image2,R.drawable.image3};
        final Button color_changer = findViewById(R.id.color);
        final Button image_changer = findViewById(R.id.im);
        final Random random = new Random();
        final ConstraintLayout layout = findViewById(R.id.main);
        // ✅ Corrected: Properly closed parenthesis and braces
        color_changer.setOnClickListener(v -> {
            layout.setBackgroundColor(
                    Color.rgb(
                            random.nextInt(256),
                            random.nextInt(256),
                            random.nextInt(256)
                    )
            );
        });
        // ✅ <-- Missing in your version
        image_changer.setOnClickListener(
                v->{
                    image_index = (image_index+1)%images.length;
                    image.setImageResource(images[image_index]);
                }
        );
    }
}
